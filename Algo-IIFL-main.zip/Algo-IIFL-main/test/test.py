import pandas as pd

df = pd.read_csv('master.csv')
print(df.columns)
# df[df['Exchange']]